<?php

class Nerdery_Suggest_Model_Observer
{

}

