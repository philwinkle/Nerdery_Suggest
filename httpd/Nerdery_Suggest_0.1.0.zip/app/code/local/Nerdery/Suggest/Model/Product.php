<?php

/**
 * @author philwinkle@gmail.com
 */

class Nerdery_Suggest_Model_Product extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('suggest/product');
    }

}

