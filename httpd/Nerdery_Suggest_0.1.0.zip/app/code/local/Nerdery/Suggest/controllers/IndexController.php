<?php

/**
 * @author philwinkle@gmail.com
 */

class Nerdery_Suggest_IndexController extends Mage_Core_Controller_Front_Action {


    /**
     * Retrieve customer session model object
     *
     * @return Nerdery_Suggest_Model_Session
     */
    protected function _getSession()
    {
        return Mage::getSingleton('suggest/session');
    }

    /**
     * Local method to determine if viewing or voting is allowed 
     * @return null 
     */
    protected function _verifyLoggedIn() {

        //redirect customer to login screen with a message before creation
        if(!Mage::getSingleton('customer/session')->isLoggedIn()){
            Mage::getSingleton('customer/session')->addError('You must be logged in to perform this action.');
            $this->_redirect('customer/account/login/');
        }

    }

    /**
     * The index of product suggestion listings
     */
    public function indexAction() {
		
        $this->loadLayout();
        $this->_initLayoutMessages('suggest/session');
	    $this->renderLayout();
    }

    /**
     * The creation form for product suggestions
     */
	public function createAction(){

        $this->_verifyLoggedIn();

        //default if logged in
        $this->loadLayout();
		$this->_initLayoutMessages('suggest/session');
	    $this->renderLayout();
	}

    /**
     * The form post action interface for product suggestions
     */
	public function createPostAction(){

        $session = $this->_getSession();

		try { 

			$params = $this->getRequest()->getParams();
			$customer_id = Mage::getSingleton('customer/session')->getCustomerId();
			$suggestion = Mage::getModel('suggest/product');

			$suggestion->setProductName($params['product_name'])
							->setProductDescription($params['product_description'])
							->setVotes(0) // new product
							->setCustomerId($customer_id)
							->save();

            $log = Mage::getModel('suggest/log');

            $log->setAction(Nerdery_Suggest_Model_Log::LOG_ACTION_SUGGEST)
                ->setCustomerId($customer_id)
                ->save();

            $session->addSuccess('Your product was added.');
            
        	$this->_redirectSuccess('suggest/index/index/');	

        } catch (Exception $e) {
            $session->setCustomerFormData($this->getRequest()->getPost())
                ->addException($e, $this->__('Another product with this name exists in our database! Please try again.'));
            $this->_redirectError('suggest/index/create/');
        }

	}

    /**
     * The public interface for voting; requires being logged in
     */
    public function voteAction(){

        $this->_verifyLoggedIn();

        $session = $this->_getSession();

        try {
            $params = $this->getRequest()->getParams();
            $customer_id = Mage::getSingleton('customer/session')->getCustomerId();
            $suggest = Mage::getModel('suggest/product')->load($params['id']);
            
            //add votes to the loaded suggestion
            $votes = $suggest->getVotes();
            $suggest->setVotes(++$votes)
                    ->save();

            //update the action log `nerdery_suggest_log`
            $log = Mage::getModel('suggest/log');

            $log->setAction(Nerdery_Suggest_Model_Log::LOG_ACTION_VOTE)
                ->setCustomerId($customer_id)
                ->save();

            $session->addSuccess('You have successfully voted! You may vote again tomorrow.');
            
            $this->_redirect('suggest/index/index/');

        } catch (Exception $e) {
            $session->addException($e, $this->__('An error occurred while registering your vote.'));
            $this->_redirect('suggest/index/index/');
        }
    }
}