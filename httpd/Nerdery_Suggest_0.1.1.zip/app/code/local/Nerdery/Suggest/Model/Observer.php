<?php

/**
 * @author philwinkle@gmail.com
 */
class Nerdery_Suggest_Model_Observer
{

}

