<?php
/**
 * @author philwinkle@gmail.com
 */
class Nerdery_Suggest_Model_Entity_Setup extends Mage_Eav_Model_Entity_Setup
{


}

