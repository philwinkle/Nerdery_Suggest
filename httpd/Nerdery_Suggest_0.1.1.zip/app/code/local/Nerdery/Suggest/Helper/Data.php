<?php
/**
 * @author philwinkle@gmail.com
 */
class Nerdery_Suggest_Helper_Data extends Mage_Core_Helper_Abstract
{


}

